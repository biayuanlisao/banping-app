# 伴屏 · ScreenPilot

一个能在这台平板上**看屏幕、点屏幕、跟你说话、替你干活、还能自己长出新能力**的 AI 智能体。
源码全在你手里，模型接口可以换成任何 OpenAI 兼容服务，也可以指向本机跑的离线模型。

适配目标：荣耀平板 GT / MagicOS 10 / Android 16 / 天玑 8350 / 8GB 内存。

---

## 一、六个能力分别落在哪

| 你要的能力 | 实现位置 | 做法 |
|---|---|---|
| 同步观察屏幕 | `screen/ScreenGrabber.kt` | MediaProjection 投一个 VirtualDisplay 到 ImageReader，只保留「最新一帧」，随时取用，不录像不编码 |
| 操控屏幕 | `control/ControlAccessibilityService.kt` | 双路径：无障碍节点树按文字点击（稳）；`dispatchGesture` 发真实手势（游戏/自绘界面可用） |
| 对话 | `agent/AgentLoop.kt` + `MainActivity.kt` | 观察→思考→动作→再观察的闭环，最多 N 步，每步把结果摊在聊天流里给你看 |
| 语音对话 | `voice/VoiceIo.kt` | 系统 TTS 朗读 + SpeechRecognizer 常开监听，唤醒词「伴屏」，播报时自动暂停识别避免回声 |
| 创建文件 | `tools/FileTools.kt` | `workspace:` / `cache:` / `plugins:` 三套沙箱前缀，拒绝 `..` 越权 |
| 自我更新代码 | `update/PluginLoader.kt` + `update_config` 动作 | 四层：改提示词 / 改配置文件 / 写 DSL 组合技能 / 热装载 DEX 插件 |

关键设计：**观察用两路信息**。视图树是文本（精确、便宜），截图是图像（兜底、贵）。
默认只发视图树，遇到图片按钮、游戏画面才带截图，8GB 内存和流量都省得下来。

---

## 二、目录结构

```
BanPing/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── .github/workflows/build.yml          ← 云端自动编译出 APK
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/
        │   ├── system_prompt.txt        ← 智能体人格与动作表（可被自己改写）
        │   └── tools.json               ← DSL 组合技能（可被自己改写）
        ├── res/
        │   ├── values/{strings,themes}.xml
        │   └── xml/accessibility_service_config.xml
        └── java/com/banping/screenpilot/
            ├── MainActivity.kt                       控制台 UI
            ├── agent/
            │   ├── AgentService.kt                   前台服务，投屏+循环+语音的宿主
            │   ├── AgentLoop.kt                      观察-思考-动作 主循环
            │   ├── LlmClient.kt                      OpenAI 兼容调用
            │   └── ConfigStore.kt                    可变配置（磁盘文本，Agent 可改）
            ├── screen/ScreenGrabber.kt               屏幕取帧
            ├── control/ControlAccessibilityService.kt 无障碍操控
            ├── voice/VoiceIo.kt                      ASR + TTS
            ├── tools/
            │   ├── FileTools.kt                      文件沙箱
            │   └── ToolRegistry.kt                   动作分发（内置/DSL/插件）
            ├── update/PluginLoader.kt                DEX 热装载
            └── plugin/ToolPlugin.kt                  插件契约接口
```

---

## 三、怎么把 APK 弄出来（三条路，任选一条）

### 路线 A：GitHub 云端编译（不用电脑，推荐）

1. 在平板或任意设备上打开 GitHub，新建仓库，把 `BanPing/` 里所有文件原样上传（注意保留 `.github/workflows/build.yml`）。
2. 推送后进 **Actions** 页，等 `Build APK` 跑完（首次约 6–10 分钟）。
3. 在该次运行底部 **Artifacts** 下载 `banping-debug-apk`，解压得到 `app-debug.apk`。
4. 传到平板安装即可。

想手动触发：Actions → Build APK → Run workflow。

> 更新版本时用同一条流水线重新构建、覆盖安装即可。debug 包每次签名不同，覆盖安装可能被系统拒绝，长期自更新建议在仓库 Secrets 里配一套固定签名，或在自己电脑上用同一个 keystore 出包。

### 路线 B：Android Studio（有电脑）

装 Android Studio → Open 选 `BanPing` 目录 → 等 Gradle 同步 → Run。
需要 JDK 17，SDK 至少装 Android 15 (API 35) 平台。

### 路线 C：命令行

```bash
cd BanPing
gradle :app:assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

---

## 四、装到平板后的四步开机

1. **开无障碍**
   `设置 → 辅助功能 → 已下载的应用 → 伴屏 · 屏幕操控 → 打开`
   打开时系统会弹「是否允许读取屏幕内容」，选允许。
2. **授权投屏**
   打开「伴屏」App，点上方 **投屏** 按钮，系统弹窗选「立即开始」。
   这一步只在每次重启后需要重做一次（Android 的安全设计，绕不过去）。
3. **给麦克风**
   点 **语音** 按钮，允许录音权限。
4. **填模型**
   点 **设置**，填三样：`base_url`、`api_key`、`model`。保存即生效。

顶部状态条会实时显示 `服务✓ 无障碍✓ 投屏✓`，三个绿灯齐了才算真正可用。

---

## 五、接哪个模型

默认走火山方舟（豆包视觉模型），因为它在中文界面上认按钮、读菜单最稳。

```
base_url = https://ark.cn-beijing.volces.com/api/v3
api_key  = 你在方舟控制台创建的 API Key
model    = 你创建的推理接入点 ID（例如 doubao-seed-1-6-vision-xxxx）
```

想离线跑：在平板上装 llama.cpp 或 Ollama，起一个 OpenAI 兼容服务，然后
`base_url = http://127.0.0.1:8080/v1`，`model = 你加载的模型名`。
断网也能用，代价是纯文本模型看不懂截图，只能靠视图树——对绝大多数操作够用。

---

## 六、自我更新是怎么实现的（四层，从软到硬）

| 层级 | 手段 | 效果 | 代码位置 |
|---|---|---|---|
| 1. 提示词层 | `update_config` 动作改 `system_prompt` | 改人格、改动作规范，下一轮生效 | `ConfigStore.systemPrompt` |
| 2. 记忆层 | 写 `memory.md` | 长期记住你的偏好和习惯 | `ConfigStore.memory` |
| 3. 技能层 | 写 `tools.json` 定义 DSL 步骤 | 用已有动作拼出新技能，例：`打开应用并等加载` | `ToolRegistry.runDsl` |
| 4. 代码层 | `load_plugin` 装载 DEX | 真正新增一段代码能力，不重装不重启 | `PluginLoader` |

第 4 层的插件契约极简，写一个类就能长出新工具：

```kotlin
// 打包成 dex 后丢进 /Android/data/com.banping.screenpilot/files/plugins/
class WeatherPlugin : ToolPlugin {
    override fun name() = "get_weather"
    override fun description() = "查询指定城市天气"
    override fun params() = JSONObject().put("city", "城市名")
    override fun invoke(args: JSONObject): String {
        val city = args.optString("city")
        // 这里可以联网、读传感器、调别的 App……
        return "$city：晴，24℃，东南风 3 级"
    }
}
```

Agent 收到 `{"action":"load_plugin","args":{"path":"plugins:weather.dex","class":"WeatherPlugin"}}`
就能把它注册进来，之后自己会主动调用。

编译 dex 用 d8：

```bash
d8 --lib $ANDROID_HOME/platforms/android-35/android.jar \
   --output out/ WeatherPlugin.kt编译出的class文件...
# out/classes.dex 改名为 weather.dex
```

APK 自身的升级仍需要用户点确认（`PackageInstaller`），这是 Android 的硬约束，任何 App 都绕不过去。

---

## 七、在这台机器上的真实性能预期

| 项目 | 预期 |
|---|---|
| 一次操作循环（含模型往返） | 3–8 秒 |
| 内存占用 | 60–120 MB（截图按 720p 压缩，单帧约 80KB） |
| 耗电 | 常开语音约 4–6 %/小时；只跑任务不常开可忽略 |
| 稳定性 | 视图树 80 节点上限，上下文不会爆；单任务默认 12 步封顶 |

触发词命中不了是常态——中文识别对短词不敏感。如果「伴屏」老是唤醒失败，把
`VoiceIo` 里的唤醒判定改成常开（`startListening(requireWakeWord = false, ...)`）。

---

## 八、安全边界（写死在代码里，不是我口头承诺）

- 涉及付款、删除、发消息这类不可逆动作，提示词强制要求先 `speak` 说明、等你确认。
- 密码框、验证码：提示词禁止转述内容，只报告「需要你手动输入」。
- 文件只能落在 App 自己的沙箱，`..` 一律拒绝，碰不到系统目录和其他 App 的数据。
- 所有配置和记忆存在本机，不上传任何第三方；除了你指定的模型接口，没有第二个出口。

---

## 九、已知限制

1. 投屏授权每次重启失效，这是 Android 14+ 的强制行为。
2. 部分 App（尤其是游戏、Flutter 自绘界面）没有可用无障碍节点，只能靠截图+坐标点，准确率会下降。
3. 荣耀 MagicOS 的省电策略可能杀后台，建议在「设置 → 电池 → 应用启动管理」里把伴屏设为**手动管理、允许自启动、允许后台活动**。
4. 语音识别依赖系统服务；如果平板没有可用的识别引擎，语音对话会静默失效，此时打字输入仍然正常。
