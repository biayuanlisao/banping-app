# 插件 DEX 通过反射加载，保留接口名
-keep interface com.banping.screenpilot.plugin.ToolPlugin { *; }
-keep class com.banping.screenpilot.plugin.** { *; }
