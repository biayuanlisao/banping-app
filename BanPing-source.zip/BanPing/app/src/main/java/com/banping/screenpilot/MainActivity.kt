package com.banping.screenpilot

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.banping.screenpilot.agent.AgentLoop
import com.banping.screenpilot.agent.AgentService
import com.banping.screenpilot.control.ControlAccessibilityService
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * 一个极简的控制台：说话、看它每一步在干什么、开权限。
 * 真正的活都在 AgentService 里跑，所以切到别的 App 也不影响。
 */
class MainActivity : AppCompatActivity() {

    private lateinit var feed: LinearLayout
    private lateinit var scroller: ScrollView
    private lateinit var input: EditText
    private lateinit var statusBar: TextView
    private var service: AgentService? = null
    private var bound = false

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = (binder as? AgentService.LocalBinder)?.service()
            service = s
            bound = true
            s?.onEvent = { ev -> runOnUiThread { renderEvent(ev) } }
            refreshStatus()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
            service = null
            refreshStatus()
        }
    }

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, AgentService::class.java).apply {
                action = AgentService.ACTION_ATTACH_PROJECTION
                putExtra(AgentService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(AgentService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(i)
            toast("投屏授权成功，屏幕观察已连接")
            refreshStatus()
        } else {
            toast("你取消了投屏授权，观察功能不可用")
        }
    }

    private val notiLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        askNotificationPermission()
    }

    override fun onStart() {
        super.onStart()
        AgentService.start(this)
        bindService(Intent(this, AgentService::class.java), conn, Context.BIND_AUTO_CREATE)
        refreshStatus()
    }

    override fun onStop() {
        if (bound) {
            runCatching { unbindService(conn) }
            bound = false
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ------------------------------------------------------------ UI

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0E1116.toInt())
            setPadding(dp(16), dp(56), dp(16), dp(16))
        }

        val title = TextView(this).apply {
            text = "伴屏"
            setTextColor(Color.WHITE)
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
        }
        root.addView(title)

        statusBar = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFF8B96A5.toInt())
            setPadding(0, dp(6), 0, dp(10))
        }
        root.addView(statusBar)

        scroller = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        feed = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroller.addView(feed)
        root.addView(scroller)

        // 权限 / 功能按钮行
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(8))
        }
        bar.addView(chip("无障碍", 0xFF2A3140.toInt()) { openAccessibilitySettings() })
        bar.addView(chip("投屏", 0xFF2A3140.toInt()) { requestProjection() })
        bar.addView(chip("语音", 0xFF2A3140.toInt()) { toggleVoice() })
        bar.addView(chip("设置", 0xFF2A3140.toInt()) { openSettings() })
        root.addView(bar)

        // 输入行
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "告诉它要做什么，例如：打开相计算器算 12×34"
            setHintTextColor(0xFF6E7781.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 1
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        inputRow.addView(input)

        val send = Button(this).apply {
            text = "发送"
            setOnClickListener { submit() }
        }
        inputRow.addView(send)
        root.addView(inputRow)

        setContentView(root)
        bubble("已启动。先开「无障碍」，再点「投屏」，之后你说什么它就做什么。", true)
    }

    private fun chip(label: String, color: Int, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(color)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            layoutParams = lp
            setOnClickListener { onClick() }
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun bubble(text: String, mine: Boolean = false, dim: Boolean = false) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = if (dim) 12f else 14f
            setTextColor(if (dim) 0xFF8B96A5.toInt() else Color.WHITE)
            setBackgroundColor(if (mine) 0xFF1E2733.toInt() else 0xFF161C26.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dp(3), 0, dp(3)) }
        }
        feed.addView(tv)
        scroller.post { scroller.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------ 事件渲染

    private fun renderEvent(ev: AgentLoop.Event) {
        when (ev) {
            is AgentLoop.Event.Status -> bubble(ev.text, dim = true)
            is AgentLoop.Event.Thought -> bubble("第${ev.step}步 想：${ev.text}", dim = true)
            is AgentLoop.Event.Action -> bubble("第${ev.step}步 ${ev.name} → ${ev.observation}")
            is AgentLoop.Event.Final -> {
                bubble(ev.text)
                service?.voice?.speak(ev.text)
                refreshStatus()
            }
            is AgentLoop.Event.Failure -> bubble("出错：${ev.text}", dim = true)
        }
        refreshStatus()
    }

    private fun refreshStatus() {
        val acc = if (ControlAccessibilityService.isReady()) "无障碍✓" else "无障碍✗"
        val scr = if (service?.isScreenReady() == true) "投屏✓" else "投屏✗"
        val svc = if (AgentService.isAlive()) "服务✓" else "服务✗"
        statusBar.text = "$svc  $acc  $scr"
    }

    // ------------------------------------------------------------ 动作

    private fun submit() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        bubble(text, mine = true)

        val s = service
        if (s == null) {
            toast("服务还没起来，稍等一下再试")
            return
        }
        if (!ControlAccessibilityService.isReady()) {
            bubble("还没开无障碍，我只能看着不能动手。点上方「无障碍」去开启。", dim = true)
        }
        if (!s.isScreenReady()) {
            bubble("还没授权投屏，我看不到屏幕。点上方「投屏」。", dim = true)
        }
        s.ask(text)
    }

    private fun openAccessibilitySettings() {
        toast("请在列表里找到「伴屏 · 屏幕操控」并打开")
        runCatching {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }.onFailure { toast("打不开无障碍设置：${it.message}") }
    }

    private fun requestProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private var voiceOn = false

    private fun toggleVoice() {
        val s = service ?: run { toast("服务未启动"); return }
        if (!hasMic()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2001)
            return
        }
        voiceOn = !voiceOn
        if (voiceOn) {
            s.startVoiceLoop()
            toast("语音常开，说「伴屏 ……」触发")
        } else {
            s.stopVoiceLoop()
            toast("语音已关闭")
        }
    }

    private fun hasMic(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun openSettings() {
        val s = service ?: run { toast("服务未启动"); return }
        val cfg = s.config
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }

        fun field(hint: String, value: String, onSave: (String) -> Unit) {
            val et = EditText(this).apply {
                this.hint = hint
                setText(value)
                textSize = 14f
            }
            container.addView(et)
            fieldSavers.add { onSave(et.text.toString().trim()) }
        }

        field("接口地址 base_url", cfg.baseUrl) { cfg.baseUrl = it }
        field("API Key", cfg.apiKey) { cfg.apiKey = it }
        field("模型名 model", cfg.model) { cfg.model = it }
        field("单次任务最多步数", cfg.maxSteps.toString()) { it.toIntOrNull()?.let { v -> cfg.maxSteps = v } }

        MaterialAlertDialogBuilder(this)
            .setTitle("模型接入")
            .setMessage("默认走火山方舟。也可以填本地 llama.cpp 的 http://127.0.0.1:8080/v1 实现离线。")
            .setView(container)
            .setPositiveButton("保存") { _, _ ->
                fieldSavers.forEach { it() }
                fieldSavers.clear()
                toast("已保存，下一轮生效")
            }
            .setNegativeButton("取消") { _, _ -> fieldSavers.clear() }
            .show()
    }

    private val fieldSavers = ArrayList<() -> Unit>()

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notiLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
