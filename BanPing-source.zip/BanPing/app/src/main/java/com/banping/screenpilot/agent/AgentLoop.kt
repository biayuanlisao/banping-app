package com.banping.screenpilot.agent

import android.content.Context
import android.util.Log
import com.banping.screenpilot.control.ControlAccessibilityService
import com.banping.screenpilot.screen.ScreenGrabber
import com.banping.screenpilot.tools.ToolRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * 智能体主循环：观察 → 思考 → 动作 → 再观察。
 *
 * 每一轮不是把整段对话历史都塞进去，而是：
 *   系统提示词（含能力清单）+ 本轮对话（用户指令 + 最近若干步的操作记录）+ 最新一帧观察。
 * 这样上下文不会随步数无限膨胀，8GB 内存的平板也扛得住。
 */
class AgentLoop(
    private val context: Context,
    private val cfg: ConfigStore,
    private val tools: ToolRegistry,
    private val llm: LlmClient,
    private val grabber: () -> ScreenGrabber?,
    private val emit: (Event) -> Unit,
) {

    sealed class Event {
        data class Status(val text: String) : Event()
        data class Thought(val step: Int, val text: String) : Event()
        data class Action(val step: Int, val name: String, val observation: String) : Event()
        data class Final(val text: String) : Event()
        data class Failure(val text: String) : Event()
    }

    private val busy = Mutex()

    /** 最近几步的操作轨迹，压缩成短文本后随请求带上，避免模型原地打转 */
    private val trail = ArrayDeque<String>()

    suspend fun ask(userText: String) = busy.withLock {
        trail.clear()
        val messages = JSONArray()

        // 1. 系统提示
        messages.put(JSONObject().apply {
            put("role", "system")
            put("content", buildSystemPrompt())
        })

        // 2. 用户指令
        messages.put(JSONObject().apply {
            put("role", "user")
            put("content", userText)
        })

        var finished = false
        var lastReply = ""

        for (step in 1..cfg.maxSteps) {
            emit(Event.Status("第 $step 步：正在观察屏幕…"))

            val observation = buildObservation()
            messages.put(JSONObject().apply {
                put("role", "user")
                put("content", observation.toContentArray())
            })

            val reply = llm.chat(messages)
            lastReply = reply

            if (reply.startsWith("调用模型失败") || reply.startsWith("网络异常")) {
                emit(Event.Failure(reply))
                return@withLock
            }

            val action = parseAction(reply)
            if (action == null) {
                emit(Event.Failure("模型输出不是合法 JSON，原文：\n" + reply.take(400)))
                return@withLock
            }

            val thought = action.optString("thought")
            val name = action.optString("action")
            val args = action.optJSONObject("args") ?: JSONObject()

            emit(Event.Thought(step, thought))

            // 把模型的原始意图写回对话，让它知道自己做过什么
            messages.put(JSONObject().apply {
                put("role", "assistant")
                put("content", action.toString())
            })

            val result = withContext(Dispatchers.IO) { tools.execute(name, args) }

            if (result.finished) {
                emit(Event.Final(result.finalText))
                finished = true
                return@withLock
            }

            emit(Event.Action(step, name, result.observation))
            trail.addLast("$step. $name → ${result.observation.take(120)}".replace("\n", " "))

            // 动作之后给界面一点时间稳定，再观察
            delay(if (name == "wait") 0 else 450)
        }

        if (!finished) {
            emit(Event.Final("我连着试了 ${cfg.maxSteps} 步还没完成，先停下了。最后一次模型输出：\n" + lastReply.take(400)))
        }
    }

    // ------------------------------------------------------------ 提示词

    private fun buildSystemPrompt(): String = buildString {
        append(cfg.systemPrompt)
        append(tools.catalogForPrompt())
        val mem = cfg.memory
        if (mem.isNotBlank()) {
            append("\n## 长期记忆\n").append(mem.take(1500)).append('\n')
        }
        append("\n## 当前设备\n")
        append("- 无接触摸屏平板，屏幕坐标原点在左上角\n")
        append("- 无障碍服务状态：").append(if (ControlAccessibilityService.isReady()) "已连接" else "未连接（只能观察不能操作）").append('\n')
        append("- 投屏状态：").append(if (grabber()?.hasFrame() == true) "已连接" else "未连接").append('\n')
        if (trail.isNotEmpty()) {
            append("\n## 本次已执行的操作\n")
            trail.takeLast(8).forEach { append("- ").append(it).append('\n') }
            append("不要重复已经做过的动作。\n")
        }
    }

    private fun buildObservation(): String = buildString {
        append("【当前界面观察】\n")
        val svc = ControlAccessibilityService.inst
        if (svc != null) {
            append(svc.dumpUi(60))
        } else {
            append("无障碍服务未连接，无法读取视图树。\n")
        }
        if (grabber()?.hasFrame() == true) append("\n（随附截图一张，如视图树信息不足可参照截图坐标）\n")
    }

    private fun String.toContentArray(): JSONArray {
        val arr = JSONArray()
        arr.put(LlmClient.textPart(this))
        if (cfg.visionEnabled) {
            val jpeg = grabber()?.captureJpeg(720, 65)
            if (jpeg != null) arr.put(LlmClient.imagePart(jpeg))
        }
        return arr
    }

    // ------------------------------------------------------------ 解析

    private fun parseAction(raw: String): JSONObject? {
        val cleaned = raw.trim()
            .removePrefix("```json").removePrefix("```")
            .removeSuffix("```")
            .trim()

        runCatching { return JSONObject(cleaned) }
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start >= 0 && end > start) {
            runCatching { return JSONObject(cleaned.substring(start, end + 1)) }
                .onFailure { Log.w(TAG, "JSON 解析失败：${it.message}") }
        }
        return null
    }

    companion object {
        private const val TAG = "AgentLoop"
    }
}
