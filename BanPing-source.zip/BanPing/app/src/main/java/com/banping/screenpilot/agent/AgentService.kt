package com.banping.screenpilot.agent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import com.banping.screenpilot.MainActivity
import com.banping.screenpilot.control.ControlAccessibilityService
import com.banping.screenpilot.screen.ScreenGrabber
import com.banping.screenpilot.tools.FileTools
import com.banping.screenpilot.tools.ToolRegistry
import com.banping.screenpilot.update.PluginLoader
import com.banping.screenpilot.voice.VoiceIo
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * 常驻服务：投屏 + 智能体循环 + 语音监听都挂在这里。
 *
 * 为什么必须是前台服务：屏幕上操作别的 App 时，伴屏自己的界面是不可见的，
 * 只有前台服务能继续持有投屏、继续拍照、继续跑循环。
 */
class AgentService : Service() {

    private val binder = LocalBinder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    lateinit var grabber: ScreenGrabber
        private set
    lateinit var voice: VoiceIo
        private set
    lateinit var tools: ToolRegistry
        private set

    private lateinit var cfg: ConfigStore
    private lateinit var loop: AgentLoop

    var onEvent: ((AgentLoop.Event) -> Unit)? = null
        set(value) {
            field = value
            pendingEvents.forEach { value?.invoke(it) }
            pendingEvents.clear()
        }

    private val pendingEvents = ArrayList<AgentLoop.Event>()
    private var running = false

    inner class LocalBinder : Binder() {
        fun service(): AgentService = this@AgentService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        instance = this
        cfg = ConfigStore.get(this)
        grabber = ScreenGrabber(this)
        voice = VoiceIo(this).apply { init() }
        val files = FileTools(this)
        val plugins = PluginLoader(this)
        tools = ToolRegistry(this, files, plugins, voice).apply {
            bindScreen { grabber }
        }
        loop = AgentLoop(this, cfg, tools, LlmClient(cfg), { grabber }) { ev ->
            dispatch(ev)
        }
        startForegroundWithNotification("伴屏已就绪")
    }

    private fun dispatch(ev: AgentLoop.Event) {
        if (onEvent == null) {
            pendingEvents.add(ev)
        } else {
            onEvent?.invoke(ev)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null) {
            when (intent.action) {
                ACTION_ATTACH_PROJECTION -> attachProjection(intent)
                ACTION_STOP -> {
                    stopSelf()
                    return START_NOT_STICKY
                }
            }
        }
        return START_STICKY
    }

    private fun attachProjection(intent: Intent) {
        val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
        if (data == null) {
            dispatch(AgentLoop.Event.Failure("投屏授权数据丢失，请重新授权"))
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        val projection = mpm.getMediaProjection(code, data)
        val ok = grabber.start(projection)
        dispatch(AgentLoop.Event.Status(if (ok) "屏幕观察已连接" else "屏幕观察启动失败"))
    }

    // ------------------------------------------------------------ 对外能力

    fun isScreenReady(): Boolean = grabber.isReady()

    fun ask(text: String) {
        if (running) {
            dispatch(AgentLoop.Event.Status("上一条任务还在执行，已排队"))
            return
        }
        running = true
        scope.launch {
            try {
                loop.ask(text)
            } catch (e: Exception) {
                Log.e(TAG, "loop crashed", e)
                dispatch(AgentLoop.Event.Failure("执行中断：${e.javaClass.simpleName} ${e.message}"))
            } finally {
                running = false
            }
        }
    }

    fun startVoiceLoop() {
        voice.startListening { said ->
            dispatch(AgentLoop.Event.Status("听到：$said"))
            ask(said)
        }
    }

    fun stopVoiceLoop() = voice.stopListening()

    val config: ConfigStore get() = cfg

    // ------------------------------------------------------------ 通知

    private fun startForegroundWithNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "伴屏运行状态", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }

        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("伴屏正在运行")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTI_ID, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTI_ID, notification)
        }
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        runCatching { voice.stopListening() }
        runCatching { grabber.release() }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "AgentService"
        private const val CHANNEL = "banping_running"
        private const val NOTI_ID = 1001

        const val ACTION_ATTACH_PROJECTION = "banping.attach_projection"
        const val ACTION_STOP = "banping.stop"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        @Volatile
        var instance: AgentService? = null
            private set

        fun isAlive(): Boolean = instance != null

        fun start(context: Context) {
            val i = Intent(context, AgentService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }
    }
}
