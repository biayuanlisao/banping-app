package com.banping.screenpilot.agent

import android.content.Context
import java.io.File

/**
 * 所有可变配置都存在这里。
 * 关键设计：配置本身是磁盘上的文本，Agent 可以自己改，改完立刻 call reload() 生效。
 */
class ConfigStore private constructor(context: Context) {

    private val prefs = context.getSharedPreferences("banping", Context.MODE_PRIVATE)
    private val assetDir = File(context.filesDir, "assets").apply { mkdirs() }

    var baseUrl: String
        get() = prefs.getString("base_url", DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
        set(v) = prefs.edit().putString("base_url", v).apply()

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v).apply()

    var model: String
        get() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = prefs.edit().putString("model", v).apply()

    var maxSteps: Int
        get() = prefs.getInt("max_steps", 12)
        set(v) = prefs.edit().putInt("max_steps", v).apply()

    /** 是否每一步都附带截图（更准，但更慢更贵） */
    var visionEnabled: Boolean
        get() = prefs.getBoolean("vision", true)
        set(v) = prefs.edit().putBoolean("vision", v).apply()

    /** 语音连续监听（免唤醒词常开） */
    var voiceAlwaysOn: Boolean
        get() = prefs.getBoolean("voice_always", false)
        set(v) = prefs.edit().putBoolean("voice_always", v).apply()

    var systemPrompt: String
        get() = readOrSeed("system_prompt.txt", FALLBACK_PROMPT)
        set(v) = writeAsset("system_prompt.txt", v)

    var toolsJson: String
        get() = readOrSeed("tools.json", "{\"tools\":[]}")
        set(v) = writeAsset("tools.json", v)

    var memory: String
        get() = readOrSeed("memory.md", "")
        set(v) = writeAsset("memory.md", v)

    /** 把 assets 里的出厂文件复制到 filesDir，之后 Agent 改的是 filesDir 里的副本 */
    fun seedAssets(context: Context) {
        listOf("system_prompt.txt", "tools.json").forEach { name ->
            val target = File(assetDir, name)
            if (!target.exists()) {
                runCatching {
                    context.assets.open(name).use { input ->
                        target.outputStream().use { out -> input.copyTo(out) }
                    }
                }
            }
        }
    }

    private fun readOrSeed(name: String, fallback: String): String {
        val f = File(assetDir, name)
        return if (f.exists()) f.readText() else fallback
    }

    private fun writeAsset(name: String, content: String) {
        File(assetDir, name).writeText(content)
    }

    companion object {
        const val DEFAULT_BASE_URL = "https://ark.cn-beijing.volces.com/api/v3"
        const val DEFAULT_MODEL = "doubao-seed-1-6-vision-250815"

        private const val FALLBACK_PROMPT = "你是运行在安卓平板上的屏幕助手。"

        @Volatile
        private var inst: ConfigStore? = null

        fun get(context: Context): ConfigStore =
            inst ?: synchronized(this) {
                inst ?: ConfigStore(context.applicationContext).also { it.seedAssets(context) ; inst = it }
            }
    }
}
