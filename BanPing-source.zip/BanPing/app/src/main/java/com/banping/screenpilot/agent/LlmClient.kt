package com.banping.screenpilot.agent

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * 模型调用层。走 OpenAI 兼容的 /chat/completions 协议，所以三种后端都能接：
 *  · 火山方舟 / 豆包（默认）
 *  · 任何 OpenAI 兼容云服务
 *  · 平板上跑的 llama.cpp / Ollama 本地服务（http://127.0.0.1:8080/v1），断网也能用
 */
class LlmClient(private val cfg: ConfigStore) {

    suspend fun chat(messages: JSONArray, temperature: Double = 0.2): String = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("model", cfg.model)
            put("messages", messages)
            put("temperature", temperature)
            put("max_tokens", 1024)
            put("stream", false)
        }

        val url = URL(cfg.baseUrl.trimEnd('/') + "/chat/completions")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (cfg.apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer ${cfg.apiKey}")
        }

        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.let {
                BufferedReader(InputStreamReader(it, "UTF-8")).use { r -> r.readText() }
            }.orEmpty()

            if (code !in 200..299) {
                return@withContext "调用模型失败 HTTP $code：${raw.take(300)}"
            }

            val json = JSONObject(raw)
            val choices = json.optJSONArray("choices")
            choices?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                ?: "模型没有返回内容：${raw.take(200)}"
        } catch (e: Exception) {
            "网络异常：${e.javaClass.simpleName} ${e.message ?: ""}"
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        /** 把 JPEG 转成 data url，放进 content 数组里 */
        fun imagePart(jpeg: ByteArray): JSONObject = JSONObject().apply {
            put("type", "image_url")
            put("image_url", JSONObject().put(
                "url",
                "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP)
            ))
        }

        fun textPart(text: String): JSONObject = JSONObject().apply {
            put("type", "text")
            put("text", text)
        }
    }
}
