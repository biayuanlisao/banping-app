package com.banping.screenpilot.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

/**
 * 屏幕操控的执行端。
 *
 * 两条路径：
 *  1. 语义路径 —— 遍历视图树，按文字/控件类型找到节点直接 performAction，比坐标稳。
 *  2. 像素路径 —— dispatchGesture 发真实手势，用于游戏、画布、自绘界面这类没有节点的情况。
 */
class ControlAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 只维护「最近一次窗口变化」，供 Agent 判断界面是否还在加载
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastPackage = event.packageName?.toString() ?: lastPackage
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (inst === this) inst = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- 观察

    /**
     * 把当前界面拍成一份紧凑的文本清单，直接喂给模型。
     * 只输出「有内容或有交互」的节点，避免一棵树上千个空容器把上下文撑爆。
     */
    fun dumpUi(maxNodes: Int = 80): String {
        val root = rootInActiveWindow ?: return "UI树获取失败：当前没有可读窗口"
        val sb = StringBuilder()
        val counter = intArrayOf(0)
        sb.append("当前应用: ").append(lastPackage ?: "未知").append('\n')
        sb.append("屏幕尺寸: ").append(rootScreenSize()).append('\n')
        sb.append("节点格式: [序号][控件类] 文字 | 坐标(l,t,r,b) | 标记\n")
        walk(root, sb, counter, 0, maxNodes)
        root.recycle()
        if (counter[0] == 0) return sb.append("（本界面没有可读节点，请用 screenshot 观察）").toString()
        return sb.toString()
    }

    private fun walk(node: AccessibilityNodeInfo, sb: StringBuilder, counter: IntArray, depth: Int, max: Int) {
        if (counter[0] >= max || depth > 12) return

        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val label = if (text.isNotEmpty()) text else desc
        val clickable = node.isClickable
        val editable = node.isEditable
        val scrollable = node.isScrollable

        val interesting = label.isNotEmpty() || clickable || editable || scrollable
        if (interesting) {
            counter[0]++
            val rect = Rect()
            node.getBoundsInScreen(rect)
            sb.append('[').append(counter[0]).append("][")
                .append(node.className?.toString()?.substringAfterLast('.') ?: "View").append(']')
            if (label.isNotEmpty()) sb.append(' ').append(label.take(80))
            sb.append(" | ").append(rect.left).append(',').append(rect.top)
                .append(',').append(rect.right).append(',').append(rect.bottom)
            if (clickable) sb.append(" | 可点击")
            if (editable) sb.append(" | 可输入")
            if (scrollable) sb.append(" | 可滚动")
            if (node.isChecked) sb.append(" | 已勾选")
            if (!node.isEnabled) sb.append(" | 已禁用")
            sb.append('\n')
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            walk(child, sb, counter, depth + 1, max)
            child.recycle()
        }
    }

    private fun rootScreenSize(): String {
        val r = resources.displayMetrics
        return "${r.widthPixels}x${r.heightPixels}"
    }

    // ---------------------------------------------------------------- 操控

    /** 按文字找节点并点击。文字全等优先，其次包含。 */
    fun clickByText(target: String, index: Int = 0): String {
        val root = rootInActiveWindow ?: return "失败：没有可读窗口"
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all)
        val exact = all.filter { it.text?.toString()?.trim() == target || it.contentDescription?.toString()?.trim() == target }
        val pool = if (exact.isNotEmpty()) exact
        else all.filter { (it.text?.toString()?.contains(target) == true) || (it.contentDescription?.toString()?.contains(target) == true) }

        if (pool.isEmpty()) return "失败：界面上找不到「$target」"
        if (index >= pool.size) return "失败：「$target」只匹配到 ${pool.size} 个，没有第 ${index + 1} 个"

        val node = pool[index]
        // 自己不可点就往上找最近的可点父节点
        var cur: AccessibilityNodeInfo? = node
        var guard = 0
        while (cur != null && !cur.isClickable && guard < 6) {
            cur = cur.parent
            guard++
        }
        val targetNode = cur ?: node
        val ok = targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val desc = targetNode.text?.toString()?.ifEmpty { null } ?: targetNode.contentDescription?.toString() ?: target
        if (ok) return "已点击「$desc」"
        // 兜底：节点点不动就按坐标补一刀
        val rect = Rect()
        targetNode.getBoundsInScreen(rect)
        val fallback = click(rect.centerX(), rect.centerY())
        return "语义点击被拒，改用坐标：$fallback"
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out.add(node)
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            collect(c, out)
        }
    }

    fun click(x: Int, y: Int): String = gesture(x, y, x, y, 120)

    fun longPress(x: Int, y: Int, ms: Long): String = gesture(x, y, x, y, ms)

    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long): String = gesture(x1, y1, x2, y2, ms)

    private fun gesture(x1: Int, y1: Int, x2: Int, y2: Int, ms: Long): String {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            if (x1 != x2 || y1 != y2) lineTo(x2.toFloat(), y2.toFloat())
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, ms.coerceAtLeast(50))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val ok = dispatchGesture(gesture, null, null)
        return if (ok) "手势已发送 ($x1,$y1)->($x2,$y2)" else "手势被系统拒绝"
    }

    /** 向当前焦点输入框写入文字 */
    fun inputText(text: String): String {
        val focused = findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: rootInActiveWindow?.let { findEditable(it) }
            ?: return "失败：当前没有处于输入状态的输入框"
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (ok) "已写入 ${text.length} 个字符" else "写入被拒绝，该输入框可能禁止程序设置文本"
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable && node.isFocusable) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            val r = findEditable(c)
            if (r != null) return r
        }
        return null
    }

    fun back(): String = global(AccessibilityService.GLOBAL_ACTION_BACK, "返回")
    fun home(): String = global(AccessibilityService.GLOBAL_ACTION_HOME, "回桌面")
    fun recents(): String = global(AccessibilityService.GLOBAL_ACTION_RECENTS, "最近任务")

    private fun global(action: Int, name: String): String =
        if (performGlobalAction(action)) "$name 已执行" else "$name 失败"

    companion object {
        @Volatile
        var inst: ControlAccessibilityService? = null
            private set

        @Volatile
        private var lastPackage: String? = null

        fun currentPackage(): String? = lastPackage

        fun isReady(): Boolean = inst != null
    }
}
