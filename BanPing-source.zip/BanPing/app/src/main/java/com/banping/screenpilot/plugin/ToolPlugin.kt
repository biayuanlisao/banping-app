package com.banping.screenpilot.plugin

import org.json.JSONObject

/**
 * 插件契约。用户的 DEX 插件只要实现这个接口，就能被 Agent 动态注册成一个新动作。
 * 这是「自我更新代码」的落地点：不重装 APK，也能长出新能力。
 */
interface ToolPlugin {
    /** 动作名，Agent 用这个名字调用 */
    fun name(): String

    /** 给模型看的说明，一句话 */
    fun description(): String

    /** 参数说明，给模型看的，例如 {"url":"要抓取的网页地址"} */
    fun params(): JSONObject = JSONObject()

    /** 真正执行，返回给 Agent 的观察结果字符串 */
    fun invoke(args: JSONObject): String
}
