package com.banping.screenpilot.screen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import java.io.ByteArrayOutputStream

/**
 * 屏幕同步观察的核心。
 *
 * 原理：MediaProjection 投出一个 VirtualDisplay，输出到 ImageReader。
 * ImageReader 每来一帧就更新「最新帧」，Agent 要观察时取最新帧即可——
 * 不需要录像，也不需要持续编码，功耗可控。
 */
class ScreenGrabber(private val context: Context) {

    @Volatile
    private var latest: Bitmap? = null

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val main = Handler(Looper.getMainLooper())

    var width = 0
        private set
    var height = 0
        private set
    private var density = 1

    fun isReady(): Boolean = virtualDisplay != null

    fun start(projection: MediaProjection): Boolean {
        if (virtualDisplay != null) return true
        this.projection = projection

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        width = metrics.widthPixels
        height = metrics.heightPixels
        density = metrics.densityDpi

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        imageReader = reader

        reader.setOnImageAvailableListener({ r ->
            val image = try { r.acquireLatestImage() } catch (e: Exception) { null }
            if (image != null) {
                try {
                    val bmp = toBitmap(image)
                    if (bmp != null) {
                        val old = latest
                        latest = bmp
                        if (old != null && old !== bmp && !old.isRecycled) old.recycle()
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "frame decode failed: ${e.message}")
                } finally {
                    image.close()
                }
            }
        }, main)

        virtualDisplay = projection.createVirtualDisplay(
            "banping-screen",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, main
        )

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                release()
            }
        }, main)

        return true
    }

    private fun toBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bmp = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bmp.copyPixelsFromBuffer(buffer)
        return if (rowPadding == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, image.width, image.height)
    }

    /** 取一帧并压缩成 JPEG。maxWidth 越小越快，给模型的图 720p 足够判断布局。 */
    fun captureJpeg(maxWidth: Int = 720, quality: Int = 70): ByteArray? {
        val src = latest ?: return null
        val scaled = if (src.width > maxWidth) {
            val h = (src.height.toFloat() * maxWidth / src.width).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(src, maxWidth, h, true)
        } else src

        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
        if (scaled !== src) scaled.recycle()
        return out.toByteArray()
    }

    /** 是否已经收到过第一帧，用来判断投屏是否真的连上 */
    fun hasFrame(): Boolean = latest != null

    fun release() {
        runCatching { virtualDisplay?.release() }
        runCatching { imageReader?.close() }
        runCatching { projection?.stop() }
        virtualDisplay = null
        imageReader = null
        projection = null
        latest?.let { if (!it.isRecycled) it.recycle() }
        latest = null
    }

    companion object {
        private const val TAG = "ScreenGrabber"
    }
}
