package com.banping.screenpilot.tools

import android.content.Context
import com.banping.screenpilot.update.PluginLoader
import java.io.File

/**
 * 文件能力。
 *
 * 路径规则（Agent 侧统一用这套前缀，避免它接触到系统敏感目录）：
 *   workspace:xxx   -> /Android/data/包名/files/workspace/xxx   长期文件，卸载才会清
 *   cache:xxx       -> /Android/data/包名/cache/xxx            临时文件
 *   plugins:xxx     -> /Android/data/包名/files/plugins/xxx    插件 DEX
 * 拒绝一切 ../ 越权路径。
 */
class FileTools(private val context: Context) : PluginLoader.FileToolsLike {

    override fun resolvePlugin(path: String): File = resolve(path)

    private fun base(): File = File(context.getExternalFilesDir(null) ?: context.filesDir, "workspace").apply { mkdirs() }
    private fun cacheBase(): File = File(context.cacheDir, "workspace").apply { mkdirs() }
    private fun pluginBase(): File = File(context.getExternalFilesDir(null) ?: context.filesDir, "plugins").apply { mkdirs() }

    private fun resolve(path: String): File {
        val normalized = path.replace('\\', '/')
        require(!normalized.contains("..")) { "路径里不允许出现 .." }
        return when {
            normalized.startsWith("cache:") -> File(cacheBase(), normalized.removePrefix("cache:").trimStart('/'))
            normalized.startsWith("plugins:") -> File(pluginBase(), normalized.removePrefix("plugins:").trimStart('/'))
            normalized.startsWith("workspace:") -> File(base(), normalized.removePrefix("workspace:").trimStart('/'))
            else -> File(base(), normalized.trimStart('/'))
        }
    }

    fun write(path: String, content: String, append: Boolean = false): String {
        val f = resolve(path)
        f.parentFile?.mkdirs()
        if (append && f.exists()) f.appendText(content) else f.writeText(content)
        return "已写入 ${displayPath(f)}（${f.length()} 字节）"
    }

    fun read(path: String): String {
        val f = resolve(path)
        if (!f.exists()) return "文件不存在：$path"
        if (f.length() > 2_000_000) return "文件过大（${f.length()} 字节），拒绝整体读入"
        return f.readText()
    }

    fun list(path: String): String {
        val d = if (path.isBlank()) base() else resolve(path)
        if (!d.exists()) return "目录不存在：$path"
        if (!d.isDirectory) return "${displayPath(d)} 是一个文件，${d.length()} 字节"
        val items = d.listFiles()?.sortedBy { it.name } ?: emptyList()
        if (items.isEmpty()) return "${displayPath(d)} 是空目录"
        return buildString {
            append(displayPath(d)).append(" 下共 ${items.size} 项\n")
            items.take(100).forEach {
                append(if (it.isDirectory) "[目录] " else "[文件] ")
                append(it.name)
                if (it.isFile) append("  ${it.length()}B")
                append('\n')
            }
        }.trimEnd()
    }

    fun delete(path: String): String {
        val f = resolve(path)
        if (!f.exists()) return "不存在：$path"
        val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
        return if (ok) "已删除 ${displayPath(f)}" else "删除失败，可能被占用"
    }

    fun exists(path: String): Boolean = resolve(path).exists()

    private fun displayPath(f: File): String {
        val root = context.getExternalFilesDir(null) ?: context.filesDir
        return when {
            f.absolutePath.startsWith(pluginBase().absolutePath) -> "plugins:" + f.relativeTo(pluginBase()).path
            f.absolutePath.startsWith(base().absolutePath) -> "workspace:" + f.relativeTo(base()).path
            f.absolutePath.startsWith(cacheBase().absolutePath) -> "cache:" + f.relativeTo(cacheBase()).path
            else -> f.absolutePath.removePrefix(root.absolutePath)
        }
    }

    fun workspaceRoot(): String = base().absolutePath
    fun pluginRoot(): String = pluginBase().absolutePath
}
