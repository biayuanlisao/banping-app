package com.banping.screenpilot.tools

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.banping.screenpilot.agent.ConfigStore
import com.banping.screenpilot.control.ControlAccessibilityService
import com.banping.screenpilot.screen.ScreenGrabber
import com.banping.screenpilot.update.PluginLoader
import com.banping.screenpilot.voice.VoiceIo
import org.json.JSONArray
import org.json.JSONObject

/**
 * 动作分发中心。
 *
 * 三类动作：
 *  - 内置动作：点、滑、输入、返回、开应用、读写文件、说话……
 *  - DSL 动作：tools.json 里用内置动作拼出来的组合技能，Agent 可以自己写新的
 *  - 插件动作：DEX 插件提供的能力
 */
class ToolRegistry(
    private val context: Context,
    private val files: FileTools,
    private val plugins: PluginLoader,
    private val voice: VoiceIo,
) {

    private var grabber: () -> ScreenGrabber? = { null }

    fun bindScreen(g: () -> ScreenGrabber?) { grabber = g }

    /** 返回给模型的「观察结果」字符串，同时把是否终结本轮告知调用方 */
    data class Result(val observation: String, val finished: Boolean, val finalText: String = "")

    fun execute(action: String, args: JSONObject): Result {
        // DSL 组合技能优先，其次插件，最后内置
        if (dslTool(action) != null) return runDsl(action, args)
        if (plugins.loadedNames().contains(action)) {
            return Result("插件「$action」返回：\n" + plugins.call(action, args.toString()))
        }

        return when (action) {
            "click" -> {
                val svc = ControlAccessibilityService.inst ?: return fail("无障碍服务没开，无法点击")
                Result(svc.click(args.optInt("x"), args.optInt("y")))
            }
            "click_node" -> {
                val svc = ControlAccessibilityService.inst ?: return fail("无障碍服务没开，无法点击")
                val text = args.optString("text")
                if (text.isBlank()) return fail("click_node 缺少 text")
                Result(svc.clickByText(text, args.optInt("index", 0)))
            }
            "long_press" -> {
                val svc = ControlAccessibilityService.inst ?: return fail("无障碍服务没开")
                Result(svc.longPress(args.optInt("x"), args.optInt("y"), args.optLong("ms", 800)))
            }
            "swipe" -> {
                val svc = ControlAccessibilityService.inst ?: return fail("无障碍服务没开")
                Result(svc.swipe(args.optInt("x1"), args.optInt("y1"), args.optInt("x2"), args.optInt("y2"), args.optLong("ms", 400)))
            }
            "input_text" -> {
                val svc = ControlAccessibilityService.inst ?: return fail("无障碍服务没开")
                Result(svc.inputText(args.optString("text")))
            }
            "back" -> Result(ControlAccessibilityService.inst?.back() ?: "无障碍服务没开")
            "home" -> Result(ControlAccessibilityService.inst?.home() ?: "无障碍服务没开")
            "recents" -> Result(ControlAccessibilityService.inst?.recents() ?: "无障碍服务没开")
            "open_app" -> Result(openApp(args))
            "wait" -> {
                val ms = args.optLong("ms", 1000).coerceIn(100, 5000)
                Thread.sleep(ms)
                Result("等待 ${ms}ms 完成")
            }
            "screenshot" -> Result(if (grabber()?.hasFrame() == true) "已重新截取屏幕，附件为最新画面" else "截图失败：没有画面，请检查投屏授权")
            "fs_write" -> Result(files.write(args.optString("path"), args.optString("content"), args.optBoolean("append", false)))
            "fs_read" -> Result(files.read(args.optString("path")))
            "fs_list" -> Result(files.list(args.optString("path", "")))
            "fs_delete" -> Result(files.delete(args.optString("path")))
            "speak" -> {
                val t = args.optString("text")
                voice.speak(t)
                Result("已朗读：$t")
            }
            "load_plugin" -> Result(pluginLoad(args))
            "unload_plugin" -> Result(plugins.unload(args.optString("name")))
            "call_plugin" -> {
                val n = args.optString("name")
                Result("插件「$n」返回：\n" + plugins.call(n, args.optJSONObject("args")?.toString() ?: "{}"))
            }
            "update_config" -> Result(updateConfig(args))
            "final" -> Result("任务结束", finished = true, finalText = args.optString("text"))
            else -> Result("未知动作：$action")
        }
    }

    private fun fail(msg: String) = Result(msg)

    // ------------------------------------------------------------ 应用启动

    private fun openApp(args: JSONObject): String {
        val pkg = args.optString("package").takeIf { it.isNotBlank() }
        val name = args.optString("name").takeIf { it.isNotBlank() }

        val target = pkg ?: run {
            if (name == null) return "open_app 需要 package 或 name"
            findByLabel(name)
        } ?: return "没有找到叫「$name」的应用"

        val intent = context.packageManager.getLaunchIntentForPackage(target)
            ?: return "应用 $target 没有可启动的入口"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "已打开 $target"
    }

    private fun findByLabel(name: String): String? {
        val pm = context.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val q = name.lowercase()
        apps.firstOrNull { pm.getApplicationLabel(it).toString().lowercase() == q }?.let { return it.packageName }
        apps.firstOrNull { pm.getApplicationLabel(it).toString().lowercase().contains(q) }?.let { return it.packageName }
        return null
    }

    // ------------------------------------------------------------ 自我更新

    private fun pluginLoad(args: JSONObject): String {
        val path = args.optString("path")
        val cls = args.optString("class")
        if (path.isBlank() || cls.isBlank()) return "load_plugin 需要 path 和 class"
        return plugins.load(files, path, cls, args.optString("name").ifBlank { null })
    }

    /** Agent 改自己的配置：模型、步数上限、系统提示词、记忆 */
    private fun updateConfig(args: JSONObject): String {
        val cfg = ConfigStore.get(context)
        var changed = 0
        args.optString("system_prompt").takeIf { it.isNotBlank() }?.let { cfg.systemPrompt = it; changed++ }
        args.optString("memory").takeIf { it.isNotBlank() }?.let { cfg.memory = it; changed++ }
        args.optString("model").takeIf { it.isNotBlank() }?.let { cfg.model = it; changed++ }
        args.optInt("max_steps", 0).takeIf { it > 0 }?.let { cfg.maxSteps = it; changed++ }
        if (args.has("vision")) { cfg.visionEnabled = args.optBoolean("vision"); changed++ }
        return if (changed > 0) "已更新 $changed 项配置，下一轮立即生效" else "没有可更新的字段"
    }

    // ------------------------------------------------------------ DSL 组合技能

    private fun dslTool(name: String): JSONObject? = runCatching {
        val arr = JSONArray(ConfigStore.get(context).toolsJson).optJSONArray("tools") ?: JSONArray()
        (0 until arr.length()).map { arr.getJSONObject(it) }.firstOrNull { it.optString("name") == name }
    }.getOrNull()

    private fun runDsl(name: String, args: JSONObject): Result {
        val tool = dslTool(name) ?: return Result("没有这个技能：$name")
        val steps = tool.optJSONArray("steps") ?: return Result("技能「$name」没有定义步骤")
        val log = StringBuilder()
        for (i in 0 until steps.length()) {
            val step = steps.optJSONObject(i) ?: continue
            val action = substitute(step.optString("action"), args)
            val stepArgs = substituteJson(step.optJSONObject("args") ?: JSONObject(), args)
            val r = execute(action, stepArgs)
            log.append("第 ${i + 1} 步 ").append(action).append("：").append(r.observation).append('\n')
            if (r.finished) break
        }
        return Result("技能「$name」执行完毕\n$log")
    }

    private fun substitute(s: String, args: JSONObject): String {
        var out = s
        args.keys().forEach { k -> out = out.replace("\$$k", args.optString(k)) }
        return out
    }

    private fun substituteJson(obj: JSONObject, args: JSONObject): JSONObject {
        val out = JSONObject()
        obj.keys().forEach { k ->
            val v = obj.get(k)
            out.put(k, if (v is String) substitute(v, args) else v)
        }
        return out
    }

    // ------------------------------------------------------------ 给模型的能力清单

    fun catalogForPrompt(): String = buildString {
        append("\n## 你还能调用的组合技能\n")
        val tools = runCatching {
            JSONArray(ConfigStore.get(context).toolsJson).optJSONArray("tools") ?: JSONArray()
        }.getOrNull()
        if (tools != null && tools.length() > 0) {
            for (i in 0 until tools.length()) {
                val t = tools.optJSONObject(i) ?: continue
                append("- ").append(t.optString("name")).append("：").append(t.optString("description"))
                val p = t.optJSONArray("params")
                if (p != null && p.length() > 0) append("  参数:").append(p.toString())
                append('\n')
            }
        } else append("（暂无）\n")
        append(plugins.descriptorForPrompt())
    }
}
