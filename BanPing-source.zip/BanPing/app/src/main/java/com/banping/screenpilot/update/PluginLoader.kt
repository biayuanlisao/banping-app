package com.banping.screenpilot.update

import android.content.Context
import android.util.Log
import com.banping.screenpilot.plugin.ToolPlugin
import dalvik.system.DexClassLoader
import java.io.File

/**
 * 自我更新代码的实现层。
 *
 * 一条 DEX 就是一段新代码：把它丢进 plugins 目录，指定类名，这里用 DexClassLoader 装载，
 * 反射实例化，注册成一个新动作。整个过程不重装、不重启。
 *
 * 同时它也负责「热替换」：同一个名字的新版本 DEX 会覆盖旧实例。
 */
class PluginLoader(private val context: Context) {

    private val loaded = HashMap<String, ToolPlugin>()   // name -> plugin
    private val loaders = ArrayList<DexClassLoader>()

    fun loadedNames(): List<String> = loaded.keys.toList()

    fun all(): List<ToolPlugin> = loaded.values.toList()

    /**
     * @param dexPath  plugins:xxx.dex 这种格式
     * @param className 插件类的完整包名，例如 com.example.WeatherPlugin
     * @param name      注册给 Agent 用的动作名，留空则用插件自己 name()
     */
    fun load(files: FileToolsLike, dexPath: String, className: String, name: String?): String {
        return try {
            val dexFile = files.resolvePlugin(dexPath)
            if (!dexFile.exists()) return "装载失败：找不到 $dexPath"
            if (!dexFile.name.endsWith(".dex") && !dexFile.name.endsWith(".jar") && !dexFile.name.endsWith(".apk")) {
                return "装载失败：插件必须是 .dex / .jar / .apk"
            }

            val optDir = File(context.codeCacheDir, "plugin-opt").apply { mkdirs() }
            val loader = DexClassLoader(
                dexFile.absolutePath,
                optDir.absolutePath,
                context.applicationInfo.nativeLibraryDir,
                context.classLoader
            )
            loaders.add(loader)

            val clazz = loader.loadClass(className)
            val ctor = clazz.getDeclaredConstructor()
            ctor.isAccessible = true
            val plugin = ctor.newInstance() as ToolPlugin

            val key = name?.takeIf { it.isNotBlank() } ?: plugin.name()
            loaded[key] = plugin
            "已装载插件「$key」：${plugin.description()}"
        } catch (e: Throwable) {
            Log.w(TAG, "load plugin failed", e)
            "装载失败：${e.javaClass.simpleName} ${e.message ?: ""}"
        }
    }

    fun call(name: String, args: String): String {
        val plugin = loaded[name] ?: return "没有名为「$name」的插件"
        return try {
            plugin.invoke(org.json.JSONObject(args.ifBlank { "{}" }))
        } catch (e: Throwable) {
            "插件执行异常：${e.message}"
        }
    }

    fun unload(name: String): String {
        return if (loaded.remove(name) != null) "已卸载插件「$name」" else "没有名为「$name」的插件"
    }

    fun descriptorForPrompt(): String {
        if (loaded.isEmpty()) return ""
        return buildString {
            append("\n## 已装载的插件（用 call_plugin 调用）\n")
            loaded.forEach { (key, p) ->
                append("- ").append(key).append("：").append(p.description())
                val params = p.params()
                if (params.length() > 0) append(" 参数：").append(params.toString())
                append('\n')
            }
        }
    }

    /** 让 PluginLoader 不直接依赖 FileTools，避免循环引用 */
    interface FileToolsLike {
        fun resolvePlugin(path: String): File
    }

    companion object {
        private const val TAG = "PluginLoader"
    }
}
