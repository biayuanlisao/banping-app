package com.banping.screenpilot.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

/**
 * 语音输入输出。
 *
 * 输出：系统 TTS，中文优先，逐句播报，播报时暂停识别避免自己听到自己。
 * 输入：SpeechRecognizer 持续监听，识别到一整句就回调，播报完自动续听。
 *      免唤醒词模式靠「伴屏」开头，常开模式直接收任何话。
 */
class VoiceIo(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private val main = Handler(Looper.getMainLooper())
    private var listening = false
    private var requireWake = true
    private var onUtterance: ((String) -> Unit)? = null

    fun init() {
        if (tts != null) return
        tts = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                val r = tts?.setLanguage(Locale.SIMPLIFIED_CHINESE)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
                tts?.setSpeechRate(1.05f)
                tts?.setPitch(1.0f)
            } else {
                Log.w(TAG, "TTS 初始化失败")
            }
        }
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        init()
        // 播报期间停止识别，避免回声自我触发
        val resume = listening
        if (resume) stopListening()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "banping-${System.currentTimeMillis()}")
        main.postDelayed({
            if (resume) startListening(requireWake, onUtterance)
        }, estimateMs(text))
    }

    private fun estimateMs(text: String): Long = (text.length * 220L + 400L).coerceAtMost(20000L)

    fun isSpeaking(): Boolean = tts?.isSpeaking == true

    // ------------------------------------------------------------ 识别

    fun startListening(requireWakeWord: Boolean = true, callback: ((String) -> Unit)?) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.w(TAG, "本机没有可用的语音识别服务")
            return
        }
        callback?.let { onUtterance = it }
        requireWake = requireWakeWord
        if (listening) return
        listening = true
        launchRecognizer()
    }

    private fun launchRecognizer() {
        if (!listening) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(listener)
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900)
        }
        runCatching { recognizer?.startListening(intent) }
            .onFailure { Log.w(TAG, "启动识别失败：${it.message}") }
    }

    fun stopListening() {
        listening = false
        runCatching { recognizer?.stopListening() }
        runCatching { recognizer?.cancel() }
    }

    fun destroy() {
        stopListening()
        runCatching { recognizer?.destroy() }
        recognizer = null
        runCatching { tts?.shutdown() }
        tts = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            // 静音超时/无匹配属于正常空转，稍等再听；其余错误也自动重启，保证常开不掉线
            if (listening) main.postDelayed({ launchRecognizer() }, 700)
        }

        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()?.trim().orEmpty()
            dispatch(text)
            if (listening) main.postDelayed({ launchRecognizer() }, 300)
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun dispatch(text: String) {
        if (text.isBlank()) return
        if (requireWake && !text.contains("伴屏")) return
        val cleaned = text.replace("伴屏", "").trim().trim('，', ',', '。')
        if (cleaned.isBlank()) return
        onUtterance?.invoke(cleaned)
    }

    companion object {
        private const val TAG = "VoiceIo"
    }
}
