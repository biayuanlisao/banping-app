package sample

import com.banping.screenpilot.plugin.ToolPlugin
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * 示例插件：演示「不重装 APK 也能长出新代码能力」。
 *
 * 编译步骤（在电脑上，需要 Android SDK）：
 *   1. 先把 app 打进 APK，从 APK 里取出 classes.dex 当 --classpath，或用 --lib android.jar
 *   2. d8 --lib $ANDROID_HOME/platforms/android-35/android.jar \
 *        --classpath app/build/intermediates/javac/...（含 ToolPlugin 的编译产物） \
 *        --output out/ sample/WeatherPlugin.class
 *   3. out/classes.dex 改名 weather.dex
 *   4. 传到平板：/Android/data/com.banping.screenpilot/files/plugins/weather.dex
 *   5. 让伴屏执行：{"action":"load_plugin","args":{"path":"plugins:weather.dex","class":"sample.WeatherPlugin"}}
 *
 * 之后你问「今天天气怎么样」，它就会自己调这个插件。
 */
class WeatherPlugin : ToolPlugin {

    override fun name(): String = "get_weather"

    override fun description(): String = "查询指定城市当前天气"

    override fun params(): JSONObject = JSONObject().put("city", "城市名，例如 赣州")

    override fun invoke(args: JSONObject): String {
        val city = args.optString("city", "赣州")
        // 这里换成你实际用的天气接口即可；示例只演示调用链能通。
        val url = "https://wttr.in/$city?format=%l:+%c+%t"
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val body = conn.inputStream.bufferedReader().readText().trim()
            conn.disconnect()
            if (body.isBlank()) "$city：暂时取不到天气数据" else body
        } catch (e: Exception) {
            "$city：天气查询失败（${e.javaClass.simpleName}）"
        }
    }
}
